$.fn.extend({
	survey(id){
	let title = this;
// $.extend({
// 	leg_survey : function(ops){
		var html = '<div class="questions">';
		html += '<div class="choose">';
		html += '	<button type="button" data-type = "1" class="check">单选</button>';
		html += '	<button type="button" data-type = "2" >多选</button>';
		html += '</div>';
		html += '<input type="text" style="display: none;" name="choose" value="1" class="chooseValue"/>';
		html += '<div style="display: flex;justify-content: space-between;"><input type="text" name="title" placeholder="问题内容" /><button type="button" class="del">删除</button></div>';
		html += '<div class="content">';
		html += '<b>A:</b><div style="display: flex;justify-content: space-between;"><input type="text" name="content" placeholder="选项内容" /><button type="button" class="del">删除</button></div>';
		html += '</div>';
		html += '<div class="question">';
		html += '<button type="button" class="addQuestion">添加问题</button>';
		html += '<button type="button" class="addContent">添加选项</button>';
		html += '</div>';
		html += '</div>';
		
		function AZ() {
			var arr = [];
			for (var i = 65; i < 91; i++) {
				if (i > 90 && i < 97) {
					continue;
				}
				// 接受一个指定的 Unicode 值，然后返回一个字符串
				arr.push(String.fromCharCode(i));
			}
			return arr;
		}
		const arr = AZ();
		
		
		$(title).on("click", ".choose button", function() {
			let arr = $(this).parent().find('button');
			arr[0].className = "";
			arr[1].className = "";
			$(this)[0].className = "check"
			console.log($(this).attr("data-type"))
			$(this).parent().parent().find(".chooseValue").val($(this).attr("data-type"));
		})
		
		
		$(html).appendTo($(title));
		
		var num = 0;
		$(title).on("click", ".addQuestion", function() {
			$(html).appendTo($(this).parent().parent().parent());
		})
		
		$(title).on("click", ".addContent", function() {
			let num = $(this).parent().prev().find("input").length;
			$('<b>' + arr[num] + ':</b><div style="display: flex;justify-content: space-between;"><input type="text" name="content" placeholder="选项内容" /><button type="button" class="del">删除</button></div>')
			.appendTo($(this).parent().parent()
				.find(".content"));
		})
		
		return new Promise(function(resolve, reject){
			$(id).on("click", function() {
				const result = $('#form').serializeArray();
				var x = 0;
				let params = [];
				let temp = []; //children数据
				for (var i = 0; i < result.length; i++) {
					if (result[i].name == "title") {
						x++;
						const title = {}
						title.title = result[i].value
						title.num = result[i-1].value
						title.children = []
						params.push(title);
						temp = [];
					} else if (x > 0) {
						params[x - 1].children.push(result[i].value);
					}
				}
				resolve(params);
			})
		})
	}
});